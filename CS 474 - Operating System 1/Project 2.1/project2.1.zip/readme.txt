How to run Keller's Project 2.1:
    For this project, I have created a Makefile to
    compile and run my program. All you need to do 
    is to open up the terminal and run "make all".
    Once you are done, you can run "make clean" to
    clean up the file.